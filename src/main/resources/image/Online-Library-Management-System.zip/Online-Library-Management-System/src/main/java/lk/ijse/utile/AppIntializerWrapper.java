package lk.ijse.utile;

import lk.ijse.utile.AppIntializer;

public class AppIntializerWrapper {


    public static void main(String[] args) {
        AppIntializer.main(args);

    }



}
