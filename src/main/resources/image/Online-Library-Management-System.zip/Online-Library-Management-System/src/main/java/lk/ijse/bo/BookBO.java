package lk.ijse.bo;

import lk.ijse.dto.BookDTO;
import lk.ijse.entity.Book;

import java.sql.SQLException;
import java.util.List;


public interface BookBO extends SuperBO{

    List<Book> getBookId();

    List<BookDTO> getAllBook() throws SQLException,ClassNotFoundException;

    boolean saveBook(BookDTO dto) throws SQLException,ClassNotFoundException;


    boolean updateBook(BookDTO dto) throws SQLException,ClassNotFoundException;


    boolean deleteBook(int id) throws SQLException,ClassNotFoundException;




    BookDTO searchBook(int id) throws SQLException,ClassNotFoundException;



    Integer generateID(int id);



    Integer generateBookID(int id);
}
