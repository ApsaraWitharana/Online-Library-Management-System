package lk.ijse.dao;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import lk.ijse.config.SessionFactoryConfig;
import lk.ijse.entity.Book;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import java.util.List;

public class BookDAOImpl implements BookDAO {

  private final   Session session;

    public  BookDAOImpl(){

        session = SessionFactoryConfig.getInstance().getSession();
    }

    @Override
    public List<Book> getAll() {

        Transaction transaction = session.beginTransaction();
        Query query = session.createQuery(" FROM Book ");
        List<Book> books = query.list();
        transaction.commit();
        session.close();
        return  books;

    }

    @Override
    public List<Book> getId() {

        Transaction transaction = session.beginTransaction();
        Query query = session.createQuery(" SELECT b.id FROM Book  b");
        List<Book> bookId = query.list();
        transaction.commit();
        session.close();
        return bookId;

    }


    @Override
    public boolean save(Book book) {

        Transaction transaction = session.beginTransaction();
        try {
            session.save(book);
            transaction.commit();
            return true;
        }catch (Exception e){
            transaction.rollback();
            System.out.println(e);
            System.out.println("Book is not save");
            return false;
        }finally {
            session.close();
        }

    }

    @Override
    public boolean update(Book book) {

        Transaction transaction = session.beginTransaction();
        try {
            session.update(book);
            transaction.commit();
            return true;
        }catch (Exception e){
            transaction.rollback();
            System.out.println(e);
            System.out.println("failed");
            return false;
        }finally {
            session.close();
        }

    }

    @Override
    public boolean delete(int id) {

        Transaction transaction = session.beginTransaction();
        try {
            Book book = session.get(Book.class,id);
            session.delete(book);
            transaction.commit();
            return true;
        }catch (Exception e){
            transaction.rollback();
            System.out.println(e);
            System.out.println("failed");
            return false;
        }finally {
            session.close();

        }
    }


    @Override
    public int generateID(int book_id) {

        Transaction transaction = session.beginTransaction();
        Query query = session.createQuery("SELECT b.name FROM Book b WHERE b.id = :book_id");
        query.setParameter("book_id",book_id);
        String id = (String) query.getSingleResult();
        transaction.commit();
        session.close();
        return Integer.parseInt(id);

    }


    @Override
    public Book search(int id) {
        return null;
    }

    public ObservableList<Book> getDetailsToTableView() {
        Transaction transaction = session.beginTransaction();
        List<Book> dataList = session.createQuery("FROM Book",Book.class).list();
        transaction.commit();
        session.close();

        ObservableList<Book> observableList = FXCollections.observableArrayList(dataList);
        return observableList;
    }
}
