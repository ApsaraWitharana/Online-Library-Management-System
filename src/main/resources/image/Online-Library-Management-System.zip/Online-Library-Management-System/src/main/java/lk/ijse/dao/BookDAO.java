package lk.ijse.dao;

import lk.ijse.entity.Book;

import java.util.List;

public interface BookDAO extends CrudDAO<Book,String> {

    List<Book> getAll();

    List<Book> getId();

    boolean save(Book entity);

    boolean update(Book entity);


    boolean delete(int id);

    int generateID(int book_id);

    Book search(int id) ;
}
