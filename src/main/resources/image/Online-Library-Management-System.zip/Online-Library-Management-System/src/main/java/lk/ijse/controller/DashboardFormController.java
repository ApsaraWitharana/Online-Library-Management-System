package lk.ijse.controller;

import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;

public class DashboardFormController {

    @FXML
    private BarChart<?, ?> barChart;

}
