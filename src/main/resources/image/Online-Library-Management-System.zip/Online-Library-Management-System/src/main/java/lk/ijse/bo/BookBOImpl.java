package lk.ijse.bo;

import javafx.collections.ObservableList;
import lk.ijse.dao.BookDAO;
import lk.ijse.dao.BookDAOImpl;
import lk.ijse.dto.BookDTO;
import lk.ijse.entity.Book;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookBOImpl implements BookBO{

    BookDAO bookDAO= new BookDAOImpl();

    @Override
    public List<Book> getBookId() {
        return bookDAO.getId();
    }

    @Override
   public List<BookDTO> getAllBook() {
        List<Book> books = bookDAO.getAll();
        List<BookDTO> bookDTOS = new ArrayList<>();
        for (Book list : books) {
            bookDTOS.add(new BookDTO(list.getId(),list.getTitle(),list.getStream(),list.getAuthor(),list.getStatus(),list.getQty()));

        }
        return bookDTOS;
   }

   @Override
   public boolean saveBook(BookDTO dto) {
       return bookDAO.save(new Book(dto.getId(),dto.getTitle(),dto.getStream(),dto.getAuthor(),dto.getStatus(),dto.getQty()));
   }

   @Override
   public boolean updateBook(BookDTO dto) {
         return bookDAO.update(new Book(dto.getId(),dto.getTitle(),dto.getStream(),dto.getAuthor(),dto.getStatus(),dto.getQty()));
    }

    @Override
   public boolean deleteBook(int id){
      return bookDAO.delete(id);

    }

    @Override
   public BookDTO searchBook(int id) {
       Book book = (Book) bookDAO.search(id);
       return new BookDTO(book.getId(),book.getTitle(),book.getStream(),book.getAuthor(),book.getStatus(),book.getQty());
    }



    @Override
    public Integer generateID(int id) {
        return bookDAO.generateID(id);
    }


    @Override
    public Integer generateBookID(int id) {
        return bookDAO.generateID(id);
    }

    public ObservableList<Book> getDetailsToTableView() {
       return (ObservableList<Book>) bookDAO.getAll();
    }
}
